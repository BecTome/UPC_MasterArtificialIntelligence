package eu.su.mas.dedaleEtu.princ;

public class Utils {
    public static final int TICK_TIME = 300;
}